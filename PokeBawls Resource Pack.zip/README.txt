HOW TO ADD A NEW DIMENSION (e.g. when your "more to come" dimensions are ready)
================================================================================

Each dimension needs up to 3 things in this pack:

1) TEXT LABEL (required) — controls the Waystones group header text
   File: assets/waystones/lang/en_us.json
   Add a line:
     "waystones.groups.dimension.<namespace>.<path>": "Your Display Name"

   Example, for a custom dimension "kanto:cerulean_cave":
     "waystones.groups.dimension.kanto.cerulean_cave": "Cerulean Cave"

2) VANILLA TEXT LABEL (optional) — controls F3 debug screen / death & respawn
   messages / world creation UI, if the mod registers it as a proper dimension
   type with a translatable name.
   File: assets/minecraft/lang/en_us.json
   Add a line:
     "dimension.<namespace>.<path>": "Your Display Name"

3) GROUP ICON (optional, cosmetic) — the small icon shown next to the group
   in the Waystones selection/management screen.
   File location:
     assets/waystones/textures/gui/sprites/groups/dimension/<namespace>/<path>.png
   Must be a 20x20 PNG, transparent background recommended.
   Then add the icon's label in assets/waystones/lang/en_us.json:
     "waystones.groups.dimension.<namespace>.<path>": "Your Display Name"
   (Same key as step 1 — one entry covers both the text label and the icon name.)

   A placeholder example icon has been included at:
     assets/waystones/textures/gui/sprites/groups/dimension/example/placeholder_moon.png
   Replace/rename this file to match your real dimension's namespace/path,
   or delete it if you don't want custom icons — Waystones will just use its
   default icon if none is provided.

FINDING A DIMENSION'S NAMESPACE:PATH
-------------------------------------
In-game, press F3 and look under your coordinates — it's shown as
"namespace:path", e.g. "kanto:cerulean_cave".

AFTER EDITING
-------------
Re-zip the pack.mcmeta + assets folder into a .zip and redistribute to players
(or re-upload to wherever your server serves the resource pack from).
